import cv2
import os
import numpy as np
from insightface.app import FaceAnalysis

app = FaceAnalysis(name='buffalo_s', providers=['CPUExecutionProvider'])
app.prepare(ctx_id=0, det_size=(640, 640))

known_embs = []  
known_names = [] 
root_dir = 'faces'

if os.path.exists(root_dir):
    for name in os.listdir(root_dir):
        person_dir = os.path.join(root_dir, name)

        feats = []
        for file in os.listdir(person_dir):
            if file.lower().endswith(('.jpg', '.png', '.jpeg')):
                img = cv2.imread(os.path.join(person_dir, file))
                if img is None: continue
                
                # 提取特征
                res = app.get(img)
                if res:
                    feats.append(res[0].embedding)

        if feats:
            # 计算多张照片的平均特征向量，并归一化
            mean_emb = np.mean(feats, axis=0)
            mean_emb = mean_emb / np.linalg.norm(mean_emb)
            known_embs.append(mean_emb)
            known_names.append(name)

print(f"加载完成: {known_names}")

cap = cv2.VideoCapture(0)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret: break
    faces = app.get(frame)

    for face in faces:
        curr_emb = face.embedding / np.linalg.norm(face.embedding)
        
        name = "Unknown"
        score = 0.0
        if known_embs:
            scores = np.dot(known_embs, curr_emb)
            best_idx = np.argmax(scores)
            score = scores[best_idx]

            if score > 0.5: 
                name = known_names[best_idx]

        box = face.bbox.astype(int)
        color = (0, 255, 0) if name != "Unknown" else (0, 0, 255)

        cv2.rectangle(frame, (box[0], box[1]), (box[2], box[3]), color, 2)

        cv2.putText(frame, f"{name} ({score:.2f})", (box[0], box[1] - 10), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)

    cv2.imshow('Face Recognition', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()