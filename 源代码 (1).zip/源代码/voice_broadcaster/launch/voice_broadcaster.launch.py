from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='voice_broadcaster',
            executable='detection_subscriber',
            name='detection_voice_broadcaster',
            output='screen'
        )
    ])
