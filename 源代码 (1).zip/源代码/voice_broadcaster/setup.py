from setuptools import find_packages, setup

setup(
    name='voice_broadcaster',
    version='0.0.1',
    packages=find_packages(),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/voice_broadcaster']),
        ('share/voice_broadcaster', ['package.xml']),
        ('share/voice_broadcaster/launch', ['launch/voice_broadcaster.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='wheeltec',
    maintainer_email='wheeltec@example.com',
    description='Voice broadcaster for YOLOv8 detection',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'detection_subscriber = voice_broadcaster.detection_subscriber:main',
        ],
    },
)
