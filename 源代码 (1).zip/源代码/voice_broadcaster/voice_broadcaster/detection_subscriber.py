#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
from rclpy.node import Node
from ai_msgs.msg import PerceptionTargets
import os
import subprocess
import time
from collections import defaultdict

class DetectionVoiceBroadcaster(Node):
    def __init__(self):
        super().__init__('detection_voice_broadcaster')
        
        self.audio_dir = '/home/wheeltec/wheeltec_ros2/src/tts_make_ros2/audio'
        
        self.class_audio_map = {
            'banana': 'banana1.wav',
            'bottle': 'bottle1.wav',
            'person': 'person1.wav',
            'apple': 'apple1.wav',
            'mouse': 'mouse1.wav',
            'book': 'book1.wav',
            'cell phone': 'cellphone1.wav',
            'laptop': 'laptop1.wav',
        }
        
        self.announced_objects = defaultdict(float)
        self.cooldown_time = 5.0
        
        self.subscription = self.create_subscription(
            PerceptionTargets,
            '/hobot_dnn_detection',
            self.detection_callback,
            10
        )
        
        self.get_logger().info('Voice broadcast node started')
        self.get_logger().info('Audio directory: %s' % self.audio_dir)
        
    def detection_callback(self, msg):
        if not msg.targets:
            return
            
        current_time = time.time()
        
        for target in msg.targets:
            obj_type = target.type.lower()
            
            if obj_type not in self.class_audio_map:
                self.get_logger().debug(
                    'No audio mapping for class "%s"' % obj_type)
                continue
            
            track_id = target.track_id
            
            if track_id in self.announced_objects:
                last_time = self.announced_objects[track_id]
                if current_time - last_time < self.cooldown_time:
                    continue
            
            audio_file = os.path.join(
                self.audio_dir,
                self.class_audio_map[obj_type]
            )
            
            if not os.path.exists(audio_file):
                self.get_logger().warn(
                    'Audio file not found: %s' % audio_file)
                continue
            
            self.play_audio(audio_file, obj_type)
            self.announced_objects[track_id] = current_time
            
    def play_audio(self, audio_file, obj_type):
        try:
            cmd = ['aplay', '-q', audio_file]
            subprocess.Popen(cmd)
            self.get_logger().info(
                'Detected %s, playing: %s' % (obj_type, os.path.basename(audio_file)))
        except Exception as e:
            self.get_logger().error('Audio play failed: %s' % str(e))

def main(args=None):
    rclpy.init(args=args)
    node = DetectionVoiceBroadcaster()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Node stopped manually')
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
